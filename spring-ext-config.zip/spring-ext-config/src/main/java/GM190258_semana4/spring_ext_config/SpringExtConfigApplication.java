package GM190258_semana4.spring_ext_config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringExtConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringExtConfigApplication.class, args);
	}

}
