package GM190258_semana4.spring_ext_config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExtConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
